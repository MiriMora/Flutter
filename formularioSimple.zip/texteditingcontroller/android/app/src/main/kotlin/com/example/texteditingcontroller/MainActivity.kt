package com.example.texteditingcontroller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

package com.example.heroanimation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

package com.example.tiposdedatos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

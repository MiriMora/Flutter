import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cupertino TextField Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'CupertinoTextField'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({super.key, required this.title});
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(

        title: Text(widget.title),
      ),
      // VAMOS A CAMBIAR EL BODY A UNA OPCION QUE SE PUEDA HACER SCROLL
      // PARA CUANDO SE UTILICE EN UN MOVIL CUNADO SE HABRA EL TECLADO PARA
      // ESCRIBIR NO NOS TAPE EL FORMULARIO. ALT + INTRO = WIDGET ->
      // WIDGET LO CAMBIAMOS A SINGLECHILDSCROLLVIEW
      body:  Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // AQUI PONEMOS LO QUE EL USUARIO SE VA A ENCONTRAR
              Text('Formulario',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                ),
              ),
              Padding(padding: EdgeInsets.all(10),
              ),
              // AQUI VAMOS A ALOJAR LOS FORMULARIOS.
              Container(
                height: MediaQuery.of(context).size.height*0.7,
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: const [
                    Text ('Ingresa tu contraseña'),
                    TextField(
                      decoration: InputDecoration(
                        hintText: 'Introduce tu contraseña',
                      ),
            // obscureText : OCULTA EL TEXTO PARA QUE NO SE NOS VEA
                      obscureText: true,
                    ),
                    Padding(padding: EdgeInsets.all(20),),
                    Text ('Ingresa tu DateTime'),
                    TextField(
                      decoration: InputDecoration(
                        hintText: 'Introduce tu DateTime',
                      ),
                      keyboardType: TextInputType.datetime,

                    ),
                Padding(padding: EdgeInsets.all(20),),
                Text ('Ingresa tu email'),
                TextField(
                  decoration: InputDecoration(
                    hintText: 'Introduce tu email',
                  ),
                  keyboardType: TextInputType.emailAddress,
                ),
                    Padding(padding: EdgeInsets.all(20),),
                    Text ('Ingresa tu TELEFONO'),
                    TextField(
                      decoration: InputDecoration(
                        hintText: 'Introduce tu TELEFONO',
                      ),
                      keyboardType: TextInputType.phone,
                    ),
                    Padding(padding: EdgeInsets.all(20),),
                    Text ('Ingresa tu URL'),
                    TextField(
                      decoration: InputDecoration(
                        hintText: 'Introduce tu URL',
                      ),
                      keyboardType: TextInputType.url,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
    );
  }
}
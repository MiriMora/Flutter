import 'package:flutter/material.dart';

import 'comidas.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'COMIDAS APP',
      theme: ThemeData(
        primarySwatch: Colors.orange,
      ),
      home: const MyHomePage(title: 'COMIDAS APP HOME'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});



  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
// CREAMOS EL CONSTRUCTOR:
  List _comidas = [
    Comida('CarrotCake','Postre',Image.asset('Assets/Images.carrotcake.jpg')),
    Comida('RedVelvet','Postre',Image.asset('Assets/Images.redvelvet.jpg')),
    Comida('Ensalada1','entrante',Image.asset('Assets/Images.ensalada1.jpg')),
    Comida('Ensalada2','Entrante',Image.asset('Assets/Images.ensalada2.jpg')),
    Comida('Hamburguesa','Americano',Image.asset('Assets/Images.hamburguesa.jpg')),
    Comida('Hamburguesa Pollo','Americano',Image.asset('Assets/Images.hamburguesapollo.jpg')),
    Comida('Pizza Carbonara','Italiano',Image.asset('Assets/Images.pizzacarbonara.jpg')),
    Comida('Pizza Barbacoa','Italiano',Image.asset('Assets/Images.pizzabarbacoa.jpg')),
  ];

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(

        title: Text(widget.title),
      ),
      body:GridView.builder(
        // gridDelegate: NOS PERMITE CONTROLAR EL NUMERO DE COLUMNAS QUE TIENE:
        // SliverGridDelegateWithFixedCrossAxisCount
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount:3,
          ),
          itemCount: _comidas.length,
          itemBuilder:(context, index){
            final item = _comidas.elementAt(index);
            // GridTileBar : ELEMENTOS MUY SIMILARES AL LISTTILE.
            return GridTileBar(
              backgroundColor: Colors.blue,
            title: Text(
              '${item.nombre}',
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 30,
              ),
            ),
              subtitle:Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  child: item.imagen,
                ),
              ),
            );
            },
      ),
    );
  }
}

import 'package:flutter/material.dart';

import 'comidas.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'COMIDAS APP',
      theme: ThemeData(
        primarySwatch: Colors.orange,
      ),
      home: const MyHomePage(title: 'COMIDAS APP HOME'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});



  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
// CREAMOS EL CONSTRUCTOR:
 List _comidas = [
   Comida('arroz','Chino',Image.asset('Assets/Images.arroz.jpg')),
   Comida('carne','Español',Image.asset('Assets/Images.carne.jpg')),
   Comida('ensalada','Entrante',Image.asset('Assets/Images.ensalada.jpg')),
   Comida('hamburguesa','Americano',Image.asset('Assets/Images.hamburguesa.jpg')),
   Comida('sushi','Japones',Image.asset('Assets/Images.sushi.jpg')),
   Comida('tacos','Mexicano',Image.asset('Assets/Images.tacos.jpg')),
 ];

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(

        title: Text(widget.title),
      ),
      body: ListView.builder(
        // itemCount : SABER EL TAMAÑO QUE VA A TENER LA LISTA QUE
        // VAMOS A INTEGRAR
        itemCount: _comidas.length,
          // INDEX: LA POSICION DEL ELEMENTO DENTRO DE LA LISTA
          // QUE ESTAMOS MANEJANDO
          itemBuilder: (context,index){
          final item  = _comidas[index];
          return ListTile(
            title: Text('${item.nombre}',
            textAlign: TextAlign.center,
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 30,
                color: Colors.teal
              ),
            ),
            subtitle: Text(
              '${item.categoriaComida}',
              textAlign: TextAlign.center,
            ),
            // CREAMOS UN POPUP DONDE APAREZCA LA IMAGEN.
            onTap: (){
              showDialog(
                  context: context,
                  builder:(BuildContext context){
                    return AlertDialog(
                      backgroundColor: Colors.grey,
                      title: Text(
                        '${item.nombre}',
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 30,
                            color: Colors.black,
                        ),
                      ),
                      content: item.imagen,
                    );
                  }
              );
            },
          );
          }
      ),
    );
  }
}

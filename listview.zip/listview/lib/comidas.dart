import 'dart:ui';
import 'package:flutter/material.dart';

class Comida{
  String nombre;
  String categoriaComida;
  Image imagen;

  Comida (this.nombre,this.categoriaComida,this.imagen);
}
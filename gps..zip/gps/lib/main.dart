import 'package:flutter/material.dart';
import 'package:location/location.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'GPS',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'GPS APP'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  // CREAMOS UN OBJETO DE TIPO LOCATION
  Location _location = Location();
  // CREAMOS UN OBJETO DE TIPO LOCATIONDATA:
  LocationData? _locationData ;


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(

        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          children: [
            Text(
                'Posicion Actual'
            ),
            Text(
                _locationData == null
                    ? 'No hay localizacion'
                    : 'Longitud : ${_locationData!.longitude}',
              style: Theme.of(context).textTheme.displayLarge,
            ),
            Text(
              _locationData == null
                  ? 'No hay localizacion'
                  : 'Latitud : ${_locationData!.latitude}',
              style: Theme.of(context).textTheme.displayMedium,
            ),
          ],
        ),
      ),

    );
  }
  // 2º
@override
  void initState() {
    super.initState();
  _encontrarLocalizacion();
  }
  Future _encontrarLocalizacion() async{
    try{
      _locationData = await _location.getLocation();
      print(_locationData);
      setState(() {

      });
    } catch(e){
      print (e);
    }
  }
}

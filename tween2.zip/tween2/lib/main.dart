
import 'package:flutter/material.dart';
import 'dart:math' as math;

void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Animated Button',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            'Animated Button',
          ),
        ),
        body: SpinnerController(),
      ),
    );
  }
}
// CREAMOS LA CLASE SPINNERCONTROLLER
class SpinnerController extends StatefulWidget {
  const SpinnerController();

  @override
  _SpinnerControllerState createState ()=> _SpinnerControllerState();
}
// TickerProviderStateMixin : CUANDO LA PANTALLA ESTA APAGADA SIGUE GIRANDO
class _SpinnerControllerState extends State<SpinnerController> with TickerProviderStateMixin{
  late final AnimationController _controller;
  late final Animation<Color?> _tween;


  @override
  // CUANDO SE ESTA INICIALIZANDO TODO
  void initState(){
    super.initState();
    _controller = AnimationController(
        vsync: this,
        duration: Duration(
          seconds: 3,
        )
    )..forward();
    _tween = ColorTween(
        begin: Colors.lime,
        end: Colors.red
    ).animate(_controller);
  }
  @override
  void dispose(){
    _controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context){
    return Center(
      child:AnimatedBuilder(
        animation: _tween,
        builder: (context,child){
          return ElevatedButton(
              onPressed: _onTapButton,
              style: ElevatedButton.styleFrom(
                backgroundColor: _tween.value
              ),
              child: child
          );
        },
        child: Text(
          'Change my color',
        ),
      ),
    );
  }
  void _onTapButton(){
    if(_controller.status == AnimationStatus.completed){
      _controller.forward();
    } else {
      _controller.reverse();
    }
  }
}